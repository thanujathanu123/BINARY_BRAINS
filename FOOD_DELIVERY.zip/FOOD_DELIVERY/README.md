# Fudo_27-07-24
Learn how to build a stunning and fully responsive restaurant website from scratch using HTML, CSS, and JavaScript! 
